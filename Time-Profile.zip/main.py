# Creator: t.me/Dev_Scorpian
from telethon.sync import TelegramClient
from telethon.tl.functions.photos import DeletePhotosRequest, UploadProfilePhotoRequest
from telethon.tl.functions.account import UpdateProfileRequest
from PIL import Image, ImageFont, ImageDraw
from random import choice, uniform
from datetime import datetime
import time
import pytz

timee = pytz.timezone("Asia/Tehran")  # A set TimeZone

# -------------------Account information------------

api_id = 24473999  # - Api id
api_hash = "35aa3080e3a067a27ee50cc51adf5df0"  # -Api hash
# --------------------------------------------------


def number(number_str):
    number_str = number_str.replace("0", "０")
    number_str = number_str.replace("1", "１")
    number_str = number_str.replace("2", "２")
    number_str = number_str.replace("3", "３")
    number_str = number_str.replace("4", "４")
    number_str = number_str.replace("5", "５")
    number_str = number_str.replace("6", "６")
    number_str = number_str.replace("7", "７")
    number_str = number_str.replace("8", "８")
    number_str = number_str.replace("9", "９")
    number_str = number_str.replace(":", ":")
    return number_str


def gettime():
    return datetime.now(timee).strftime("%H:%M")


def draw_time_image(text, config):
    image = Image.open(config["photo"])
    image.load()
    W, H = image.size
    draw = ImageDraw.Draw(image)

    # فونت بزرگ برای زمان
    font = ImageFont.truetype(font="data/3.ttf", size=110)

    # رسم متن زمان
    _, _, wt, ht = draw.textbbox((0, 0), text, font=font)
    x = (W - wt) / 2
    y = (H - ht) / 2 - 200
    draw.text(
        (x, y),
        text,
        font=font,
        fill=choice(config["time_colors"]),
    )

    # متن دوم - جمله تاریخی
    text2 = choice(config["quotes"])

    # فونتی با اندازه قابل قبول (و نه خیلی کوچک یا خیلی بزرگ)
    font_size = 40
    font_small = ImageFont.truetype("data/3.ttf", size=font_size)

    # اگر متن بیش از عرض تصویر بود، کوچک‌تر کن تا جا بشه
    while True:
        _, _, wt2, ht2 = draw.textbbox((0, 0), text2, font=font_small)
        if wt2 <= W - 100 or font_size <= 10:  # حداقل 100px حاشیه
            break
        font_size -= 2
        font_small = ImageFont.truetype("data/3.ttf", size=font_size)

    x2 = (W - wt2) / 2
    y2 = config["quote_y"](y, ht) if callable(config["quote_y"]) else config["quote_y"]
    draw.text((x2, y2), text2, font=font_small, fill=config["quote_color"])

    image.save("data/Time.jpg")


# لیست جملات تاریخی (quotes) به صورت جداگانه
quotes = [
    "The only thing we have to fear is fear itself. — Franklin D. Roosevelt",
    "I think, therefore I am. — René Descartes",
    "To be, or not to be, that is the question. — William Shakespeare",
    "Injustice anywhere is a threat to justice everywhere. — Martin Luther King Jr.",
    "The unexamined life is not worth living. — Socrates",
    "Give me liberty, or give me death! — Patrick Henry",
    "Mr. Gorbachev, tear down this wall! — Ronald Reagan",
    "That's one small step for man, one giant leap for mankind. — Neil Armstrong",
    "Veni, vidi, vici. — Julius Caesar",
    "Let them eat cake. — Attributed to Marie Antoinette",
    "History is written by the victors. — Winston Churchill",
    "Power tends to corrupt, and absolute power corrupts absolutely. — Lord Acton",
    "The die is cast. — Julius Caesar",
    "Ask not what your country can do for you; ask what you can do for your country. — John F. Kennedy",
    "I have a dream. — Martin Luther King Jr.",
    "Float like a butterfly, sting like a bee. — Muhammad Ali",
    "The ends justify the means. — Niccolò Machiavelli",
    "Speak softly and carry a big stick. — Theodore Roosevelt",
    "Those who do not learn history are doomed to repeat it. — George Santayana",
    "Give peace a chance. — John Lennon",
    "Knowledge is power. — Francis Bacon",
    "The pen is mightier than the sword. — Edward Bulwer-Lytton",
    "Man is the measure of all things. — Protagoras",
    "The only thing necessary for the triumph of evil is for good men to do nothing. — Edmund Burke",
    "Liberty, equality, fraternity. — French Revolution slogan",
    "War is peace. Freedom is slavery. Ignorance is strength. — George Orwell",
    "I came, I saw, I conquered. — Julius Caesar",
    "Time is money. — Benjamin Franklin",
    "An eye for an eye leaves the whole world blind. — Mahatma Gandhi",
    "History will be kind to me for I intend to write it. — Winston Churchill",
    "The future belongs to those who believe in the beauty of their dreams. — Eleanor Roosevelt",
    "Imagination rules the world. — Napoleon Bonaparte",
    "Peace begins with a smile. — Mother Teresa",
    "The greatest glory in living lies not in never falling, but in rising every time we fall. — Nelson Mandela",
    "Let us never negotiate out of fear. But let us never fear to negotiate. — John F. Kennedy",
    "In the middle of difficulty lies opportunity. — Albert Einstein",
    "The best way to predict the future is to create it. — Peter Drucker",
    "A house divided against itself cannot stand. — Abraham Lincoln",
    "Do or do not. There is no try. — Yoda",
    "I disapprove of what you say, but I will defend to the death your right to say it. — Voltaire",
    "Those who cannot remember the past are condemned to repeat it. — George Santayana",
    "The only true wisdom is in knowing you know nothing. — Socrates",
    "I am the master of my fate: I am the captain of my soul. — William Ernest Henley",
    "Education is the most powerful weapon which you can use to change the world. — Nelson Mandela",
    "The courage to continue is what counts. — Winston Churchill",
    "We shall fight on the beaches. — Winston Churchill",
    "I only regret that I have but one life to lose for my country. — Nathan Hale",
    "The glory of a country lies in its heroes. — Unknown",
    "It always seems impossible until it's done. — Nelson Mandela",
    "A journey of a thousand miles begins with a single step. — Lao Tzu",
    "You miss 100% of the shots you don't take. — Wayne Gretzky",
    "Fortune favors the bold. — Latin Proverb",
    "The truth will set you free. — Jesus Christ",
    "Better to remain silent and be thought a fool than to speak and remove all doubt. — Abraham Lincoln",
    "History is a vast early warning system. — Norman Cousins",
    "All men are created equal. — Declaration of Independence",
    "Revolutions are the locomotives of history. — Karl Marx",
    "Power is not revealed by striking hard or often, but by striking true. — Honoré de Balzac",
    "A people that values its privileges above its principles soon loses both. — Dwight D. Eisenhower",
    "Men make history, and not the other way around. — Karl Marx",
    "The best revenge is massive success. — Frank Sinatra",
    "To improve is to change; to be perfect is to change often. — Winston Churchill",
    "The world breaks everyone, and afterward, some are strong at the broken places. — Ernest Hemingway",
    "Freedom is never voluntarily given by the oppressor; it must be demanded by the oppressed. — Martin Luther King Jr.",
    "History is a guide to navigation in perilous times. — David C. McCullough",
    "Those who make peaceful revolution impossible will make violent revolution inevitable. — John F. Kennedy",
    "The past cannot be changed. The future is yet in your power. — Mary Pickford",
    "The greatest threat to freedom is the absence of criticism. — Wole Soyinka",
    "The essence of democracy is its assurance of the freedom to dissent. — John F. Kennedy",
    "Liberty means responsibility. That is why most men dread it. — George Bernard Shaw",
    "The history of the world is but the biography of great men. — Thomas Carlyle",
    "You cannot shake hands with a clenched fist. — Indira Gandhi",
    "The pen is mightier than the sword. — Edward Bulwer-Lytton",
    "History is the version of past events that people have decided to agree upon. — Napoleon Bonaparte",
    "Courage is not the absence of fear, but the triumph over it. — Nelson Mandela",
    "The future depends on what you do today. — Mahatma Gandhi",
    "Democracy is the worst form of government, except for all the others. — Winston Churchill",
    "No one can make you feel inferior without your consent. — Eleanor Roosevelt",
    "Injustice anywhere is a threat to justice everywhere. — Martin Luther King Jr.",
    "We know what we are, but not what we may be. — William Shakespeare",
    "History is the witness that testifies to the passing of time. — Cicero",
    "There is nothing new under the sun. — Ecclesiastes",
    "Success is not final, failure is not fatal: It is the courage to continue that counts. — Winston Churchill",
    "The life of the dead is placed in the memory of the living. — Marcus Tullius Cicero",
    "Those who cannot remember the past are condemned to repeat it. — George Santayana",
    "The most effective way to destroy people is to deny and obliterate their own understanding of their history. — George Orwell",
    "Every moment is a fresh beginning. — T.S. Eliot",
    "History will be kind to me, for I intend to write it. — Winston Churchill",
    "If you want peace, prepare for war. — Vegetius",
    "History is the version of past events that people have decided to agree upon. — Napoleon Bonaparte",
    "A man who stands for nothing will fall for anything. — Malcolm X",
    "The only way to deal with an unfree world is to become so absolutely free that your very existence is an act of rebellion. — Albert Camus",
    "Revolutions are the locomotives of history. — Karl Marx",
    "The most important thing in communication is hearing what isn't said. — Peter Drucker",
    "History is a set of lies agreed upon. — Napoleon Bonaparte",
    "Freedom lies in being bold. — Robert Frost",
    "Do not wait to strike till the iron is hot; but make it hot by striking. — William Butler Yeats",
    "Success usually comes to those who are too busy to be looking for it. — Henry David Thoreau",
    "Change is the law of life. And those who look only to the past or present are certain to miss the future. — John F. Kennedy",
]
time_colors = [
    "#000000ff",
    "#0071c7",
    "#ffe600ff",
    "#FFFFFF",
    "#943633",
    "#6495ed",
    "#FF5E00",
    "#ae00ff",
    "#527130",
    "#064201",
    "#3d4e90",
    "#00ff80",
]
# تنظیمات هر عکس
image_configs = [
    {
        "photo": "photos/2.jpg",
        "time_colors": time_colors,
        "quote_color": "#FFFFFF",
        "quote_y": 185,
        "quotes": quotes,
    },
    {
        "photo": "photos/1.jpeg",
        "time_colors": time_colors,
        "quote_color": "#000000",
        "quote_y": lambda y, ht: y + ht + 300,
        "quotes": quotes,
    },
]


def main():
    set_time = ""
    with TelegramClient("Time&Bio", api_id, api_hash) as client:
        print("Run Time & Bio ...")
        while True:
            if not set_time == gettime():
                current_time = gettime()
                set_time = current_time
                config = choice(image_configs)
                draw_time_image(current_time, config)
                image = client.upload_file("data/Time.jpg")
                # فقط آخرین عکس پروفایل را حذف کن
                photos = client.get_profile_photos("me", limit=1)
                if photos.total > 0 and photos:
                    client(DeletePhotosRequest([photos[0]]))
                client(UploadProfilePhotoRequest(file=image))  # Updated line

                sleep_time = uniform(55, 65)
                print(f"Sleeping for {sleep_time:.2f} seconds")
                time.sleep(sleep_time)


if __name__ == "__main__":
    main()
