# Time-Profile

**Clock bot inside profile and account beautifier**
<br>
First Install Library:
```
pip install -r requirements.txt
```
<hr>
Now Running Bot:
<br>

```
python3 main.py
```
